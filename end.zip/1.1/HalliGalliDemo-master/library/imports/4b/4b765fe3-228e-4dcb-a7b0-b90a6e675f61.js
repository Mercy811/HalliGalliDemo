"use strict";
cc._RF.push(module, '4b765/jIo5Ny6ewuQpuZ19h', 'start');
// scripts/start.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    toscene: function toscene() {
        cc.director.loadScene("game");
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();