"use strict";
cc._RF.push(module, 'e86eboLE0VFwLj/mHIpRRj6', 'restart');
// scripts/restart.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    toscene: function toscene() {
        cc.director.loadScene("game");
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();