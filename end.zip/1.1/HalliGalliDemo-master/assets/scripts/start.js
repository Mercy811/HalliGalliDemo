
cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    toscene:function(){
        cc.director.loadScene("game");

    },
    start () {

    },

    // update (dt) {},
});
